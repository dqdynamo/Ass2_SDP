import java.util.Scanner;

public class CoffeeBoom {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Welcome to the Coffee Boom!");
            System.out.println("Choose a coffee type:");
            System.out.println("1. Espresso(500₸)");
            System.out.println("2. Latte(600₸)");
            System.out.println("3. Cappuccino(550₸)");
            System.out.println("0. Exit");
            int choice = scanner.nextInt();
            if (choice == 0) {
                System.out.println("Thank you for visiting!");
                break;
            }
            Coffee coffee = null;
            switch (choice) {
                case 1:
                    coffee = new Espresso();
                    break;
                case 2:
                    coffee = new Latte();
                    break;
                case 3:
                    coffee = new Cappuccino(); // Create a Cappuccino
                    break;
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
                    continue;
            }


            System.out.println("Do you want to add Syrup(150₸)? (Y/N)");
            String addSyrup = scanner.next().toLowerCase();

            if (addSyrup.equals("y")) {
                coffee = new Syrup(coffee);
            }

            System.out.println("Do you want to add sugar(70₸)? (Y/N)");
            String addSugar = scanner.next().toLowerCase();
            if (addSugar.equals("y")) {
                coffee = new Sugar(coffee);
            }

            System.out.println("Do you want to add Honey(100₸)? (Y/N)");
            String addHoney = scanner.next().toLowerCase();
            if (addHoney.equals("y")) {
                coffee = new Honey(coffee);
            }

            System.out.println("Your order: " + coffee.getDescription());
            System.out.println("Total cost: " + coffee.cost() + "₸");
        }
    }
}

