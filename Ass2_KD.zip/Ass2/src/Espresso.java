public class Espresso extends Coffee {
    public Espresso() {
        description = "Espresso";
    }

    @Override
    public int cost() {
        return 500;
    }
}