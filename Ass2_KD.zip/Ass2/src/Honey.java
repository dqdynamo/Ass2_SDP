public class Honey extends CoffeeDecorator {
    public Honey(Coffee coffee) {
        super(coffee);
    }

    @Override
    public String getDescription() {
        return coffee.getDescription() + ", honey";
    }

    @Override
    public int cost() {
        return coffee.cost() + 100;
    }
}

