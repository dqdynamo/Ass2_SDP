public class Syrup extends CoffeeDecorator {
    public Syrup(Coffee coffee) {
        super(coffee);
    }

    @Override
    public String getDescription() {
        return coffee.getDescription() + ", syrup"; //
    }

    @Override
    public int cost() {
        return coffee.cost() + 150;
    }
}
