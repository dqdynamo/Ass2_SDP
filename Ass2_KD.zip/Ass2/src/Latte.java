public class Latte extends Coffee {
    public Latte() {
        description = "latte";
    }

    @Override
    public int cost() {
        return 600;
    }
}
